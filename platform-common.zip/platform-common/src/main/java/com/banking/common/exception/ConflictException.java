package com.banking.common.exception;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) { super(message); }
}
